﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Lab4MVCandDatabase.Models
{
    public class Phone
    {
        public int id { get; set; }
        public string name { get; set; }
        public string company { get; set; }
        public int price { get; set; }
    }
}
